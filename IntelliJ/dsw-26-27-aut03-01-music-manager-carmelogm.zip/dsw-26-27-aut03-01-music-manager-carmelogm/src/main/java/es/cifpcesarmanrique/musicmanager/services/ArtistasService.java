package es.cifpcesarmanrique.musicmanager.services;


import es.cifpcesarmanrique.musicmanager.models.ArtistasModel;
import es.cifpcesarmanrique.musicmanager.repositories.ArtistasRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ArtistasService {

    @Autowired
    private ArtistasRepository artistRepository;

    public List<ArtistasModel> obtenerTodosOrdenadosPorNombreDesc() {
        return artistRepository.findAllByOrderByNombreDesc();
    }

    public Optional<ArtistasModel> obtenerArtistPorId(Integer id) {
        return artistRepository.findById(id);
    }

    public void guardarArtist(ArtistasModel artist) {
        artistRepository.save(artist);
    }

    public void eliminarArtist(Integer id) {
        artistRepository.deleteById(id);
    }
}
