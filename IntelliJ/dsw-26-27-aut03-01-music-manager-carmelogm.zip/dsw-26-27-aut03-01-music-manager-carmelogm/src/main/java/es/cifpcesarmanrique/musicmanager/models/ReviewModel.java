package es.cifpcesarmanrique.musicmanager.models;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
@Table(name = "review")
public class ReviewModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @NotBlank(message = "El título es obligatorio")
    @Size(min = 3, max = 10, message = "El título debe tener entre 3 y 10 caracteres")
    @Column(name = "title", nullable = false, length = 10)
    private String title;

    @NotBlank(message = "La descripción es obligatoria")
    @Size(min = 5, max = 30, message = "La descripción debe tener entre 5 y 30 caracteres")
    @Column(name = "description", nullable = false, length = 30)
    private String description;

    @NotNull(message = "La valoración es obligatoria")
    @Min(value = 1, message = "El rating mínimo es 1")
    @Max(value = 5, message = "El rating máximo es 5")
    @Column(name = "rating", nullable = false)
    private Integer rating;

    @ManyToOne
    @JoinColumn(name = "ArtistaId", nullable = false)
    private ArtistasModel artista;

    public ReviewModel() {
    }

    public ReviewModel(String title, String description, Integer rating, ArtistasModel artista) {
        this.title = title;
        this.description = description;
        this.rating = rating;
        this.artista = artista;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getRating() {
        return rating;
    }

    public void setRating(Integer rating) {
        this.rating = rating;
    }

    public ArtistasModel getArtista() {
        return artista;
    }

    public void setArtista(ArtistasModel artista) {
        this.artista = artista;
    }
}