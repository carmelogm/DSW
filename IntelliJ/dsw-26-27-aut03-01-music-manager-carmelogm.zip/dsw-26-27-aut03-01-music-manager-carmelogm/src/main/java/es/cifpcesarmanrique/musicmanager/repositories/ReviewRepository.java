package es.cifpcesarmanrique.musicmanager.repositories;

import es.cifpcesarmanrique.musicmanager.models.ReviewModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ReviewRepository extends JpaRepository<ReviewModel, Integer> {

    List<ReviewModel> findByArtistaId(Integer artistaId);
}