package es.cifpcesarmanrique.musicmanager.models;

import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name="artist")
public class ArtistasModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ArtistasId")
    private Integer id;

    @Column(name = "Name")
    private String nombre;

    @OneToMany(mappedBy = "artista", cascade = CascadeType.ALL)
    private List<AlbumModel> albums;

    @OneToMany(mappedBy = "artista", cascade = CascadeType.ALL)
    private List<ReviewModel> reviews;

    public ArtistasModel(){}

    public ArtistasModel(Integer id, String nombre, List<AlbumModel> albums, List<ReviewModel> reviews) {
        this.id = id;
        this.nombre = nombre;
        this.albums = albums;
        this.reviews = reviews;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public List<AlbumModel> getAlbums() {
        return albums;
    }

    public void setAlbums(List<AlbumModel> albums) {
        this.albums = albums;
    }

    public List<ReviewModel> getReviews() {
        return reviews;
    }

    public void setReviews(List<ReviewModel> reviews) {
        this.reviews = reviews;
    }
}
