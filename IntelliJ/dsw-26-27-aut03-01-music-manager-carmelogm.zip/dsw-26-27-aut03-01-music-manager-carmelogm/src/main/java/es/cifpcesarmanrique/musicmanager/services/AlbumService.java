package es.cifpcesarmanrique.musicmanager.services;

import es.cifpcesarmanrique.musicmanager.models.AlbumModel;
import es.cifpcesarmanrique.musicmanager.repositories.AlbumRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AlbumService {

    @Autowired
    private AlbumRepository albumRepository;

    public List<AlbumModel> obtenerTodosOrdenadosPorTituloDesc() {
        return albumRepository.findAllByOrderByNombreDesc();
    }

    public Optional<AlbumModel> obtenerAlbumPorId(Integer id) {
        return albumRepository.findById(id);
    }

    public void guardarAlbum(AlbumModel album) {
        albumRepository.save(album);
    }

    public void eliminarAlbum(Integer id) {
        albumRepository.deleteById(id);
    }
}