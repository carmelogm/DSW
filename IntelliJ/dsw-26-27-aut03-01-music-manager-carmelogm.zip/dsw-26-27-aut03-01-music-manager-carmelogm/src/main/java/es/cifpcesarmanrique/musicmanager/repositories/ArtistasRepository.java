package es.cifpcesarmanrique.musicmanager.repositories;

import es.cifpcesarmanrique.musicmanager.models.ArtistasModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ArtistasRepository extends JpaRepository<ArtistasModel, Integer> {

    List<ArtistasModel> findAllByOrderByNombreDesc();
}