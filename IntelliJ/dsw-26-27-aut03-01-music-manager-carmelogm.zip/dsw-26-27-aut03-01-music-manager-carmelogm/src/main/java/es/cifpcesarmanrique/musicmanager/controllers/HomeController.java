package es.cifpcesarmanrique.musicmanager.controllers;

import es.cifpcesarmanrique.musicmanager.services.AlbumService;
import es.cifpcesarmanrique.musicmanager.services.ArtistasService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    @Autowired
    private AlbumService albumService;

    @Autowired
    private ArtistasService artistasService;

    @GetMapping("/")
    public String home() {
        return "index";
    }

    @GetMapping("/login")
    public String loginPlaceholder() {
        return "login";
    }

    @GetMapping("/artistas")
    public String artistas(Model model) {
        model.addAttribute("artistas", artistasService.obtenerTodosOrdenadosPorNombreDesc());
        return "artistas";
    }

    @GetMapping("/discos")
    public String listarDiscos(Model model) {
        model.addAttribute("discos", albumService.obtenerTodosOrdenadosPorTituloDesc());
        return "discos";
    }
}