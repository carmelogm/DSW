package es.cifpcesarmanrique.musicmanager.services;

import es.cifpcesarmanrique.musicmanager.models.ArtistasModel;
import es.cifpcesarmanrique.musicmanager.models.ReviewModel;
import es.cifpcesarmanrique.musicmanager.repositories.ArtistasRepository;
import es.cifpcesarmanrique.musicmanager.repositories.ReviewRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class IniciadorService implements CommandLineRunner {

    @Autowired
    private ArtistasRepository artistasRepository;

    @Autowired
    private ReviewRepository reviewRepository;

    @Override
    public void run(String... args) throws Exception {
        crearReseñaSiNoExiste(155, "Genial", "Muy buena música", 5);

        crearReseñaSiNoExiste(212, "Excelente", "Gran artista en vivo", 4);
    }

    private void crearReseñaSiNoExiste(Integer artistId, String title, String description, Integer rating) {
        Optional<ArtistasModel> artistaOpt = artistasRepository.findById(artistId);

        if (artistaOpt.isPresent()) {
            ArtistasModel artista = artistaOpt.get();

            boolean yaTieneReseña = reviewRepository.findAll().stream()
                    .anyMatch(r -> r.getArtista() != null && r.getArtista().getId().equals(artistId));

            if (!yaTieneReseña) {
                ReviewModel review = new ReviewModel();
                review.setTitle(title);
                review.setDescription(description);
                review.setRating(rating);
                review.setArtista(artista);

                reviewRepository.save(review);
                System.out.println("Reseña de ejemplo creada para el artista ID: " + artistId);
            }
        }
    }
}