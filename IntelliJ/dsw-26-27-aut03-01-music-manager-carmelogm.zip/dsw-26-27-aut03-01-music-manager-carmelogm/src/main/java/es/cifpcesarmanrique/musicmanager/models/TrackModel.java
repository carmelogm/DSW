package es.cifpcesarmanrique.musicmanager.models;

import jakarta.persistence.*;

@Entity
@Table(name = "track")
public class TrackModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "TrackId")
    private Integer id;

    @Column(name = "Name")
    private String name;

    @ManyToOne
    @JoinColumn(name = "AlbumId")
    private AlbumModel album;

    public TrackModel() {
    }

    public TrackModel(Integer id, String name, AlbumModel album) {
        this.id = id;
        this.name = name;
        this.album = album;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public AlbumModel getAlbum() {
        return album;
    }

    public void setAlbum(AlbumModel album) {
        this.album = album;
    }
}