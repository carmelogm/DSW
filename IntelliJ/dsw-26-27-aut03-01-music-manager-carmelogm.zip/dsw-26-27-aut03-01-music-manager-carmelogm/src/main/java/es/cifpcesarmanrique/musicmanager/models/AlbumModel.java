package es.cifpcesarmanrique.musicmanager.models;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "album")
public class AlbumModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "AlbumId")
    private Integer id;

    @Column(name = "Title")
    private String nombre;

    @ManyToOne
    @JoinColumn(name = "ArtistId")
    private ArtistasModel artista;

    @OneToMany(mappedBy = "album", cascade = CascadeType.ALL)
    private List<TrackModel> tracks;

    public AlbumModel() {}

    public AlbumModel(Integer id, String nombre, ArtistasModel artista) {
        this.id = id;
        this.nombre = nombre;
        this.artista = artista;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public ArtistasModel getArtista() {
        return artista;
    }

    public void setArtista(ArtistasModel artista) {
        this.artista = artista;
    }

    public List<TrackModel> getTracks() {
        return tracks;
    }

    public void setTracks(List<TrackModel> tracks) {
        this.tracks = tracks;
    }
}